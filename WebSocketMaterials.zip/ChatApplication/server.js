var express = require('express'),
    app = express();

app.listen(8080);
app.use(['/js', '/css', '/'], express.static(__dirname));

var WebSocketServer = require('websocket').server;
var http = require('http');

var server = http.createServer(function(request, response) {
    //http logic
});
server.listen(1337, function() { });

// create the server
wsServer = new WebSocketServer({
    httpServer: server
});

var listOfActiveUsers = [];
wsServer.on('request', function(request) {
    var connection = request.accept(null, request.origin);
    listOfActiveUsers.push(connection);

    connection.on('message', function(message) {
        if (message.type === 'utf8') {
            for(var i in listOfActiveUsers) {
                listOfActiveUsers[i].send(message.utf8Data);
            }
        }
    });

    connection.on('close', function(connection) {
        // close user connection
    });
});