(function () {
    // if user is running mozilla then use it's built-in WebSocket
    window.WebSocket = window.WebSocket || window.MozWebSocket;

    connection = new WebSocket('ws://localhost:1337');

    connection.onopen = function () {
        connection.send("Hello all !!!");
    };

    connection.onerror = function (error) {
        alert("Error!!!!!");
    };

    connection.onmessage = function (message) {
        var json = message.data;
        var divEle = document.createElement('div');
        divEle.innerText = json;
        divEle.className = 'notification';
        document.getElementById('notificationWindow').appendChild(divEle);
    };
})();

var broadcastMessage = function() {
    var value = textArea.value;
    textArea.value = "";
    connection.send(value);
}

document.addEventListener('DOMContentLoaded', function() {
    textArea = document.getElementById('msgArea');
}, false);



// var socket = io.connect('/');
// socket.on('announcements', function(data) {
//     console.log(data.message);
// });